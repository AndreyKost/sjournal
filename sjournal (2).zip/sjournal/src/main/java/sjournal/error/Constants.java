package sjournal.error;

public class Constants {

    public final static String USERNAME_NOT_FOUND = "Username is not found";


}

