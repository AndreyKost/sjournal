package sjournal.service;

import sjournal.model.service.ReviewServiceModel;

import java.util.HashMap;

public interface ReviewService {
    void add(ReviewServiceModel reviewServiceModel);

    /*double getAvgScore();

    HashMap<Integer,Integer> getScoreMap();*/
}
