package sjournal.model.service;

import java.time.LocalDateTime;

public class TopicServiceModel extends BaseServiceModel{
    private String name;
    private String description;
    private LocalDateTime addedOn;

    public TopicServiceModel() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getAddedOn() {
        return addedOn;
    }

    public void setAddedOn(LocalDateTime addedOn) {
        this.addedOn = addedOn;
    }
}
